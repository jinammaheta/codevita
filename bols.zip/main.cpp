#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int h[n];
    for(int i=0;i<n;i++)
    {
        cin>>h[i];
    }
    int m;
    cin>>m;
    int b[m];
    for(int j=0;j<m;j++)
    {
        cin>>b[j];
    }
    int index[m]={0};
    for(int i=n-1;i>=0;i--)
    {
        int count=0;
        for(int j=0;j<m;j++)
        {
            if(h[i]>=b[j] && b[j]!=-1)
            {
            index[j]=i+1;
            count++;
            b[j]=-1;
            }
            if(count>=(i+1))
            break;
        }
    }
    for(int i=0;i<m;i++)
    {
        cout<<index[i]<<" ";
    }
}