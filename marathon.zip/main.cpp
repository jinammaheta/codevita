#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int t;
    cin>>t;
    int a[n][t+1];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<t+1;j++)
        cin>>a[i][j];
    }
    int count[n]={0};
    int sum[n];
    int max;
    for(int i=2;i<=(t-1);i+=2)
    {
        max=0;
        for(int j=0;j<n;j++)
        {
            
            
            sum[j]=0;
            for(int k=0;k<i;k++)
            {
                sum[j]+=a[j][k];
            }
            sum[j]*=a[j][t];
            if(max<sum[j])
            max=sum[j];
            
        }
        for(int j=0;j<n;j++)
        {
            if(sum[j]==max)
            count[j]++;
        }
       
    }
    max=0;
    int index=0;
    for(int i=0;i<n;i++)
    {
        if(max<count[i])
        {
            max=count[i];
            index=i;
        }
    }
    cout<<(index+1);
}