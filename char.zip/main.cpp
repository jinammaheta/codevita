#include<iostream>
using namespace std;
int main()
{
    long int n;
    cin>>n;
    string s;
    cin>>s;
    int al[26][n];
    int q;
    cin>>q;
    long int p[q];
    for(int i=0;i<q;i++)
    {
        cin>>p[i];
        
    }
    
    for(int j=0;j<26;j++)
    {
        if(s[0]==(j+97))
        al[j][0]=1;
        else
        al[j][0]=0;
        
    }
    
    for(int i=1;i<n;i++)
    {
        char ch=s[i];
        
        for(int j=0;j<26;j++)
        {
            char t=j+97;
            if(ch==t)
            al[j][i]=al[j][i-1]+1;
            else
            al[j][i]=al[j][i-1];
        }
    }
    
    for(int i=0;i<q;i++)
    {
        int count=0;
        char ch=s[p[i]-1];
        if(p[i]==1)
        cout<<0<<endl;
        cout<<al[ch-97][p[i]-2]<<endl;
    }
}
