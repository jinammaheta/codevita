#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int br=n*(n+1)/2;
    int start=10;
    int start2=br+1;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<(2*i);j++)
        {
            cout<<'*';
        }
        for(int j=0;j<(n-i);j++)
        {
            cout<<start;
            start+=10;
        }
        int start3=start2+(n-i)*(n-i-1)/2;
        for(int j=0;j<(n-i-1);j++)
        {
            cout<<start3<<'0';
            start3++;
        }
        cout<<start3;
        cout<<endl;
    }
}